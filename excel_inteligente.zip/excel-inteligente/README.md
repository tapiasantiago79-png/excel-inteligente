# Excel Inteligente

Aplicación local en español con Python, Streamlit, SQLite y openpyxl. Cuatro módulos, formularios para crear/editar/eliminar, tablas y exportación XLSX integral. Sin autenticación, pagos, SRI ni servicios de IA.

## Instalación

Requiere Python 3.10 o superior. Desde esta carpeta:

```bash
python -m venv .venv
# Linux / macOS
source .venv/bin/activate
# Windows (PowerShell): .venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

Abre http://localhost:8501. Detén el servidor con Ctrl+C. La interfaz se adapta al ancho disponible; en teléfonos las tablas anchas permiten desplazamiento horizontal. El menú lateral contiene navegación, ejemplos opcionales y descarga XLSX.

## Primeros pasos

1. En una base vacía puedes pulsar **Cargar ejemplos**. Nunca reemplaza datos existentes.
2. En Inventario crea productos con stock inicial, luego registra entradas/salidas. Las cantidades son unidades enteras. El stock inicial es la existencia al comienzo de todo el historial.
3. En Ventas registra fecha, producto, unidades, precio, costo unitario y medio de pago. Cada venta descuenta inventario automáticamente. No repitas esa salida en movimientos.
4. En Compras y gastos registra proveedor, fecha, concepto, categoría, importe, estado y medio de pago. Las compras no ingresan inventario automáticamente: registra la recepción en Inventario.
5. En Caja registra un cuadre por día con fondo inicial y efectivo contado. Otras entradas/salidas son movimientos distintos de las ventas y gastos ya registrados.
6. Para corregir o eliminar usa el formulario de acción bajo cada tabla. Borrar requiere una casilla de confirmación. No se permite borrar productos que tengan operaciones asociadas.

## Reglas de cálculo

- Ingresos = cantidad × precio unitario; costos = cantidad × costo unitario; ganancia bruta = ingresos − costos. La ganancia bruta no resta gastos operativos ni compras.
- Existencia = inicial + entradas − salidas manuales − unidades vendidas. Se valida todo el historial para impedir existencias negativas por fecha. Dentro del día se procesan entradas, salidas y ventas en ese orden; no hay control por hora.
- Efectivo esperado = fondo inicial + ventas en efectivo + otras entradas − compras/gastos pagados en efectivo − otras salidas. Diferencia = contado − esperado: positiva es sobrante, negativa es faltante.
- Los cuadres abarcan un día completo y se recalculan si se modifican ventas o gastos de ese día. No se arrastra el saldo del día previo: el usuario registra cada apertura.
- Compras/gastos afectan caja al estar pagados en efectivo, usando su fecha registrada. Si se pagan después, actualizar la fecha al día efectivo del pago. Esta versión no conserva fecha de devengo separada ni pagos parciales.
- Valores no negativos, importes hasta mil millones USD, textos requeridos de hasta 200 caracteres. Se permiten importes cero para cortesías. Costo de venta manual, sin valoración FIFO ni costo promedio. Dinero almacenado en centavos y redondeo decimal a dos cifras.

## Exportación profesional

El botón descarga un libro de seis hojas: Resumen, Productos, Ventas, Movimientos, Compras y gastos, Caja. Incluye tablas con filtros, encabezados, paneles inmovilizados, formato USD, fechas, configuración de impresión y fórmulas de ingresos/costos/ganancias, stock y caja. Los productos se relacionan mediante su ID estable.

Excel/LibreOffice calcula las fórmulas al abrir; openpyxl no es un motor de cálculo y no guarda resultados calculados en caché. Algunos visores sin motor de cálculo pueden mostrar celdas vacías. Se exporta una fila de fórmula vacía si no hay datos. No borres ni cambies IDs si modificas el libro. El archivo es una exportación: sus cambios no se importan a la app.

## Persistencia y respaldo

Datos en `data/negocio.sqlite3`, creado al iniciar. La variable `EXCEL_DB` permite elegir otra ruta. Las operaciones se validan dentro de transacciones SQLite con bloqueo de escritura y reversión ante errores. Haz copias del archivo con la aplicación detenida y restaura en la misma ruta. No subir la base a un repositorio.

Sin autenticación: usar en un equipo o red de confianza. Si se instala en un servidor, requiere almacenamiento persistente y control de acceso externo antes de exponer datos reales. Sites/Cloudflare Workers no ejecuta servidores Streamlit; se entrega código Python para instalación local o un servidor compatible.

## Pruebas

```bash
python -m unittest discover -s tests -v
```

Cubren redondeo, validaciones, ventas, inventario, caja, edición/eliminación, persistencia, reversión transaccional, fechas y estructura/fórmulas XLSX. Prueba de interfaz opcional con Streamlit AppTest:

```bash
python -m unittest discover -s tests -p 'ui_*.py' -v
```

## Estructura

- `app.py`: interfaz en español.
- `excel_inteligente/core.py`: validación y cálculos sin interfaz.
- `excel_inteligente/storage.py`: persistencia SQLite y ejemplos.
- `excel_inteligente/export.py`: formatos y fórmulas XLSX.
- `tests/`: pruebas básicas automatizadas.

La separación permite ampliar reportes, productos, almacenamiento o interfaz en futuras versiones.
