import tempfile
import unittest
from pathlib import Path
from io import BytesIO
from openpyxl import load_workbook
from excel_inteligente.core import cents, quantity, sale, stock, cash
from excel_inteligente.storage import Store
from excel_inteligente.export import workbook

class Calculations(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.store=Store(Path(self.temp.name)/'test.db')
        self.store.demo()
    def tearDown(self): self.temp.cleanup()
    def test_money(self):
        self.assertEqual(cents('1.005'),101)
        for value in ['NaN','-1','Infinity']:
            with self.assertRaises(ValueError): cents(value)
        with self.assertRaises(ValueError): quantity(1.5)
    def test_sales_stock_cash(self):
        data=self.store.read()
        self.assertEqual(sale(data['ventas'][0]),(7500,4200,3300))
        self.assertEqual(stock(data,'cafe'),74)
        self.assertEqual(cash(data,data['caja'][0]),(11000,0))
    def test_edit_delete_and_persistence(self):
        row=self.store.read()['ventas'][0]
        row['cantidad']=8
        self.store.change('ventas',row)
        data=Store(self.store.path).read()
        self.assertEqual(stock(data,'cafe'),72)
        self.assertEqual(cash(data,data['caja'][0]),(13500,-2500))
        self.store.change('ventas',delete=row['id'])
        self.assertEqual(stock(self.store.read(),'cafe'),80)
    def test_rejected_changes_rollback(self):
        before=self.store.read()
        row=dict(before['ventas'][0],cantidad=1000)
        with self.assertRaises(ValueError): self.store.change('ventas',row)
        with self.assertRaises(ValueError): self.store.change('productos',delete='cafe')
        with self.assertRaises(ValueError): self.store.change('caja',{k:v for k,v in before['caja'][0].items() if k!='id'})
        self.assertEqual(self.store.read(),before)
    def test_backdated_stock(self):
        self.store.change('productos',dict(id='new',nombre='Nuevo',inicial=0,minimo=0))
        self.store.change('movimientos',dict(fecha='2026-02-02',producto='new',tipo='Entrada',cantidad=5,concepto='Compra'))
        with self.assertRaises(ValueError): self.store.change('ventas',dict(fecha='2026-02-01',producto='new',cantidad=1,precio=100,costo=50,medio='Efectivo'))
    def test_workbook(self):
        data=self.store.read()
        data['gastos'][0]['concepto']='=HYPERLINK("bad")'
        wb=load_workbook(BytesIO(workbook(data)))
        self.assertEqual(len(wb.sheetnames),6)
        self.assertEqual(wb['Ventas']['H2'].value,'=D2*E2')
        self.assertEqual(wb['Caja']['J2'].value,'=F2-I2')
        self.assertEqual(wb['Compras y gastos']['D2'].data_type,'s')
        self.assertIn('SUMIFS',wb['Productos']['E2'].value)
        self.assertEqual(wb['Ventas'].freeze_panes,'B2')
        self.assertTrue(wb['Ventas'].tables)
        self.assertTrue(wb.calculation.fullCalcOnLoad)
    def test_empty_workbook(self):
        wb=load_workbook(BytesIO(workbook({k:[] for k in self.store.read()})))
        self.assertEqual(wb['Ventas']['H2'].value,'=D2*E2')

if __name__=='__main__': unittest.main()
