import os
import tempfile
import unittest
from pathlib import Path
from streamlit.testing.v1 import AppTest

class Interface(unittest.TestCase):
    def test_modules_and_demo(self):
        with tempfile.TemporaryDirectory() as tmp:
            os.environ['EXCEL_DB']=str(Path(tmp)/'ui.db')
            app=AppTest.from_file(str(Path(__file__).resolve().parents[1]/'app.py')).run(timeout=30)
            self.assertFalse(app.exception)
            app.button[0].click().run()
            self.assertFalse(app.exception)
            for section in ['Control de ventas','Cuadre de caja','Inventario','Compras y gastos','Resumen']:
                app.sidebar.radio[0].set_value(section).run()
                self.assertFalse(app.exception,section)
            del os.environ['EXCEL_DB']
